# ECO — Brand Pack v0 (UI-safe)

Este pack foi montado para incorporar identidade **sem destruir o layout atual** do PWA.

## Conteúdo
- `eco_icon_circle_color.png` — ícone principal (círculo ECO colorido)
- `eco_icon_circle_mono.png`  — variante mono (bom p/ fundo escuro)
- `mascot_badge_head.png`     — mascote (badge cabeça) p/ cantos, loaders, empty states
- `mascot_badge_full.png`     — mascote (badge corpo inteiro) p/ sucesso/recibo/convite
- `pwa_icons/icon-*.png`      — tamanhos prontos p/ manifest (512, 192, 180, 32 etc)

## Integração (mínimo risco)
1) Copie para `public/brand/eco/`:
   - `eco_icon_circle_color.png`
   - `eco_icon_circle_mono.png`
   - `mascot_badge_head.png`
   - `mascot_badge_full.png`

2) Copie para `public/icons/` (ou onde seu manifest já aponta):
   - conteúdo de `pwa_icons/` (principalmente `icon-192.png` e `icon-512.png`)

3) Atualize o manifest (exemplo):
```json
"icons": [
  { "src": "/icons/icon-192.png", "sizes": "192x192", "type": "image/png" },
  { "src": "/icons/icon-512.png", "sizes": "512x512", "type": "image/png" }
]
```

## Uso rápido na UI
- Loader/EmptyState: use `mascot_badge_head.png` (64–96px)
- Sucesso/Recibo: use `mascot_badge_full.png` (96–140px)
- Favicon/App icon: use `eco_icon_circle_color.png`